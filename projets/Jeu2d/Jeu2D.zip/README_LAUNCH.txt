Lancer le jeu (Windows)

1) Double-cliquez sur `run-game.bat` ou `Jeu2D.exe`.
2) Si la fenêtre se ferme immédiatement, ouvrez `jeu-log.txt` généré par `run-game.bat` pour voir les erreurs.
3) Si des DLL manquent (ex: SDL2.dll), assurez-vous qu'elles sont présentes dans ce dossier.
4) Si l'antivirus bloque l'exécutable, autorisez-le ou exécutez en tant qu'administrateur.

Contenu attendu dans ce dossier:
- Jeu2D.exe
- toutes les DLL (.dll) nécessaires (SDL2.dll, MonoGame.Framework.dll, etc.)
- dossier Content (sprites, sons, musiques)
- run-game.bat (lance et sauvegarde les logs dans jeu-log.txt)
